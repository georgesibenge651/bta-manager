import React, { useState } from 'react';
import { 
  Package, 
  Search, 
  Plus, 
  Clock, 
  MapPin, 
  FileText, 
  DollarSign, 
  ChevronRight, 
  ArrowLeft,
  Camera,
  Truck,
  Globe,
  Calendar,
  AlertCircle,
  MoreVertical
} from 'lucide-react';
import { CargoPackage, CargoStatus, User, CompanySettings } from '../../types';
import { formatUSD, formatDateLubumbashi, generateReferenceNumber } from '../../utils/currency';

interface CargoModuleProps {
  packages: CargoPackage[];
  settings: CompanySettings;
  currentUser: User;
  onSavePackage: (pkg: Partial<CargoPackage>) => Promise<any>;
  onAddEvent: (packageId: string, event: any) => Promise<any>;
  onAddPayment: (packageId: string, payment: any) => Promise<any>;
}

export const CargoModule: React.FC<CargoModuleProps> = ({
  packages,
  settings,
  currentUser,
  onSavePackage,
  onAddEvent,
  onAddPayment
}) => {
  const [activeTab, setActiveTab] = useState<'list' | 'dashboard' | 'new'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPackage, setSelectedPackage] = useState<CargoPackage | null>(null);

  return (
    <div className="space-y-4">
      {/* Module Header */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-tight">BTA Cargo Tracking</h2>
              <p className="text-[10px] text-slate-500 font-medium">Gestion des expéditions internationales</p>
            </div>
          </div>
          
          <button 
            onClick={() => setActiveTab('new')}
            className="p-2.5 bg-indigo-600 text-white rounded-2xl shadow-sm hover:bg-indigo-700 transition"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 mt-4 p-1 bg-slate-50 rounded-2xl border border-slate-100">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Globe },
            { id: 'list', label: 'Mes Colis', icon: Package },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold transition-all ${
                  isActive 
                    ? 'bg-white text-indigo-700 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {activeTab === 'dashboard' && (
        <div className="text-center py-10 text-slate-400 text-sm italic">
          Tableau de bord Cargo en cours d implantation...
        </div>
      )}

      {activeTab === 'list' && (
        <div className="text-center py-10 text-slate-400 text-sm italic">
          Liste des colis Cargo en cours d implantation...
        </div>
      )}
      
      {activeTab === 'new' && (
        <div className="text-center py-10 text-slate-400 text-sm italic">
          Formulaire nouveau colis en cours d implantation...
        </div>
      )}
    </div>
  );
};
